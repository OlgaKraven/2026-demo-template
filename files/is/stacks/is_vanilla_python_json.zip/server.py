from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import json, sqlite3
ROOT = Path(__file__).resolve().parent
def items():
    return json.loads((ROOT / 'data.json').read_text(encoding='utf-8'))

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        route = self.path.split('?')[0]
        if route == '/api/items':
            body, mime = json.dumps(items(), ensure_ascii=False).encode('utf-8'), 'application/json; charset=utf-8'
        elif route in ('/', '/index.html', '/app.js', '/style.css'):
            name = 'index.html' if route == '/' else route[1:]
            body = (ROOT / 'public' / name).read_bytes()
            mime = {'html':'text/html', 'js':'text/javascript', 'css':'text/css'}[name.split('.')[-1]] + '; charset=utf-8'
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)
server = HTTPServer(('127.0.0.1', 8080), Handler)
print('http://127.0.0.1:8080', flush=True)
server.serve_forever()
