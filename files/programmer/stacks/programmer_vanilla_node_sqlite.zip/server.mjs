import http from 'node:http';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {DatabaseSync} from 'node:sqlite';
const db=new DatabaseSync(fileURLToPath(new URL('catalog.sqlite',import.meta.url)));
db.exec('CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY, name TEXT NOT NULL)');
const insert=db.prepare('INSERT OR IGNORE INTO items VALUES (?, ?)');
for(const item of JSON.parse(readFileSync(new URL('data.json',import.meta.url),'utf8')))insert.run(item.id,item.name);
const items=()=>db.prepare('SELECT id, name FROM items ORDER BY id').all();
http.createServer((req,res)=>{
 if(req.method!=='GET'){res.writeHead(405);return res.end()}
 const route=new URL(req.url,'http://localhost').pathname;
 if(route==='/api/items'){res.writeHead(200,{'Content-Type':'application/json; charset=utf-8'});return res.end(JSON.stringify(items()))}
 if(!['/','/index.html','/app.js','/style.css'].includes(route)){res.writeHead(404);return res.end()}
 const name=route==='/'?'index.html':route.slice(1);
 const type={html:'text/html',js:'text/javascript',css:'text/css'}[name.split('.').pop()];
 res.writeHead(200,{'Content-Type':type+'; charset=utf-8'});res.end(readFileSync(new URL('public/'+name,import.meta.url)));
}).listen(8080,'127.0.0.1',()=>console.log('http://127.0.0.1:8080'));
